package hu.hobbijava.my_custom_camera_app.my_cam_view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import hu.hobbijava.my_custom_camera_app.R;
import hu.hobbijava.my_custom_camera_app.my_cam_controler.FileTool;
import myMapTool.MapTools;


public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private static final int REQUEST_IMAGE_CAPTURE_CODE = 1000;
    private static final int PERMISSION_REQUEST_CODE = 210;
    private static final String[] NEED_PERMISSIONS = new String[]{
            Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE
    };
    public static final String APP_MAIN_DIRECTORY = Environment.getExternalStorageDirectory() + "/" + "MY_CUSTOM_CAM_APP";
    public static final String[] APP_MAIN_CHILD_DIRS = new String[]{"WORK", "HOBBY", "FAMILY", "HOLYDAY"};
    public static final String APP_TEMP_DIRECTORY = APP_MAIN_DIRECTORY + "/" + ".tmp";
    private static final String FILEMANAGER_PACKAGE_NAME = "com.alphainventor.filemanager";


    private String tmpFilePath = null;
    private Uri imageUri;

    private File tmpImage;
    private boolean savedImage;
    private boolean camResultOK;
    private Intent cam_intent;

    static boolean yesAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.image_view);
        FileTool.clearTempDirectory();


        checkMyNeedPermission();


        savedImage = false;


    }


    private void checkMyNeedPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            List<String> deniedPermissionList = new ArrayList<>();

            for (String needpermission : NEED_PERMISSIONS) {


                if (checkSelfPermission(needpermission) == PackageManager.PERMISSION_DENIED) {

                    deniedPermissionList.add(needpermission);

                }

            }

            if (!deniedPermissionList.isEmpty()) {
                String[] denArray = (String[]) deniedPermissionList.toArray(new String[deniedPermissionList.size()]);
                requestPermissions(denArray, PERMISSION_REQUEST_CODE);
            } else {
                FileTool.makeApplicationDirectories();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //  super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            int i = 0;
            for (; i < grantResults.length; i++) {

                if (grantResults[i] == PackageManager.PERMISSION_DENIED) {

                    break;
                }

            }
            if (i == grantResults.length) {
                FileTool.makeApplicationDirectories();
            } else {
                checkMyNeedPermission();
            }

        }
    }

    public void cameraClick(View view) {
        cam_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);


        if (imageUri != null && !savedImage && camResultOK) {

            makeSaveDialog(cam_intent);

        } else {
            savedImage = false;
            openCamera(cam_intent);
        }


    }

    private void makeSaveDialog(Intent cam_intent) {


        AlertDialog.Builder builder = NoSaveAlertDialog.INSTANCE.noSaveAlertDialog(MainActivity.this);

        builder.setOnDismissListener(dialog -> {

            if (yesAnswer) {
                openCamera(cam_intent);
            } else {
                return;
            }

        });
        builder.create().show();
    }

    private void openCamera(Intent camera_intent) {
        if (cam_intent.resolveActivity(getPackageManager()) != null) {

            try {
                getFileData();

            } catch (IOException | NullPointerException | IndexOutOfBoundsException e) {
                Toast.makeText(this, "File error", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
                return;
            }


        } else {
            Toast.makeText(this, "no open camera", Toast.LENGTH_SHORT).show();
            return;
        }
        if (tmpImage != null) {
            imageUri = FileProvider.getUriForFile(this, "hu.hobbijava.my_custom_camera_app", tmpImage);
            camera_intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);

            startActivityForResult(camera_intent, REQUEST_IMAGE_CAPTURE_CODE);
        } else {
            return;
        }
    }

    private void getFileData() throws IOException, NullPointerException, IndexOutOfBoundsException {
        HashMap map = FileTool.getImageFileMap();
        tmpImage = (File) MapTools.getEntryKey(map, 0);

        tmpFilePath = (String) MapTools.getEntryValue(map, 0);

    }


    public void saveClick(View view) {

        String saveResultTEXT = null;
        final int id = view.getId();
        List saveResultList;

        switch (id) {
            case R.id.save_work_button:
                saveResultList = FileTool.saveImageFile(APP_MAIN_CHILD_DIRS[0], tmpFilePath);
                saveResultTEXT = (String) saveResultList.get(0);
                savedImage = (boolean) saveResultList.get(1);
                Toast.makeText(this, saveResultTEXT, Toast.LENGTH_LONG).show();
                break;

            case R.id.save_hobby_button:
                saveResultList = FileTool.saveImageFile(APP_MAIN_CHILD_DIRS[1], tmpFilePath);
                saveResultTEXT = (String) saveResultList.get(0);
                savedImage = (boolean) saveResultList.get(1);
                Toast.makeText(this, saveResultTEXT, Toast.LENGTH_LONG).show();
                break;
            case R.id.save_family_button:
                saveResultList = FileTool.saveImageFile(APP_MAIN_CHILD_DIRS[2], tmpFilePath);
                saveResultTEXT = (String) saveResultList.get(0);
                savedImage = (boolean) saveResultList.get(1);
                Toast.makeText(this, saveResultTEXT, Toast.LENGTH_LONG).show();
                break;

            case R.id.save_holiday_button:
                saveResultList = FileTool.saveImageFile(APP_MAIN_CHILD_DIRS[3], tmpFilePath);
                saveResultTEXT = (String) saveResultList.get(0);
                savedImage = (boolean) saveResultList.get(1);
                Toast.makeText(this, saveResultTEXT, Toast.LENGTH_LONG).show();
                break;
        }

    }

    public void openAppFolder(View view) {
        try {
            getPackageManager().getPackageInfo(FILEMANAGER_PACKAGE_NAME, 0);
            Intent fileManagerIntent = new Intent(Intent.ACTION_VIEW);
            Uri uri = Uri.parse(APP_MAIN_DIRECTORY);
            fileManagerIntent.setDataAndType(uri, "resource/folder");
            if (fileManagerIntent.resolveActivityInfo(getPackageManager(), 0) != null) {
                startActivity(fileManagerIntent);
            }

        } catch (Exception e) {
            if (e instanceof PackageManager.NameNotFoundException) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + FILEMANAGER_PACKAGE_NAME)));
            } else {
                Log.i("openfolderexception", e.getMessage());
            }


        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        System.out.println("ON ACTIVITY RESULT");
        if (requestCode == REQUEST_IMAGE_CAPTURE_CODE && resultCode == RESULT_OK) {

            Log.i("imageURI_:   ", imageUri.toString());
            imageView.setImageURI(imageUri);
            camResultOK = true;

        } else {
            camResultOK = false;
            imageView.setImageResource(R.drawable.ic_launcher_foreground);
            super.onActivityResult(requestCode, resultCode, data);
        }


    }


}
