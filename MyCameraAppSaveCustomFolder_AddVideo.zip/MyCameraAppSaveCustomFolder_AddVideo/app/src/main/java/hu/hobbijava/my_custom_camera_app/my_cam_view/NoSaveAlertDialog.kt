package hu.hobbijava.my_custom_camera_app.my_cam_view

import android.content.Context
import android.content.DialogInterface
import androidx.appcompat.app.AlertDialog


object NoSaveAlertDialog {

    fun noSaveAlertDialog(context: Context): AlertDialog.Builder? {

        val alBuilder = AlertDialog.Builder(context).setTitle("No saved file!!!!!")
                .setCancelable(false)
                .setMessage("proceed without saving?")
                .setPositiveButton("yes", DialogInterface.OnClickListener { dialog, which ->

                    if (which == -1) {
                        MainActivity.procedYesAnswer = true;
                        dialog.dismiss()
                    }
                })
                .setNegativeButton("no", DialogInterface.OnClickListener { dialog, which ->
                    if (which != -1) {
                        MainActivity.procedYesAnswer = false
                        dialog.cancel()
                    }
                })


        return alBuilder


    }


}

