package hu.hobbijava.my_custom_camera_app.my_cam_controler;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static hu.hobbijava.my_custom_camera_app.my_cam_view.MainActivity.APP_MAIN_CHILD_DIRS;
import static hu.hobbijava.my_custom_camera_app.my_cam_view.MainActivity.APP_MAIN_DIRECTORY;
import static hu.hobbijava.my_custom_camera_app.my_cam_view.MainActivity.APP_TEMP_DIRECTORY;

public final class FileTool {
    private static final String VIDEO_ACTION = "android.media.action.VIDEO_CAPTURE";
    //  private static  final String IMAGE_ACTION="android.media.action.IMAGE_CAPTURE";

    private FileTool() {
    }

    public static void clearTempDirectory() {

        File tempDir = new File(APP_TEMP_DIRECTORY);

        if (tempDir.exists() && tempDir.isDirectory()) {
            try {
                FileUtils.cleanDirectory(tempDir);
            } catch (IOException e) {
                e.printStackTrace();
                System.err.println(e.getMessage());
            }
        }
    }

    public static void makeApplicationDirectories() {
        //create main dir
        File mainDir = new File(APP_MAIN_DIRECTORY);
        if (!mainDir.exists()) {
            System.out.println("create main dir" + mainDir.mkdir());
        } else {
            System.out.println("main dir exist");
        }
        //create children dir
        for (String appMainChildDir : APP_MAIN_CHILD_DIRS) {
            File childDir = new File(APP_MAIN_DIRECTORY + "/", appMainChildDir);
            if (!childDir.exists()) {
                System.out.println("create child dir " + childDir.getName() + "  " + childDir.mkdir());
            } else {
                System.out.println("child dir exist");
            }

        }
        //create temp dir:
        File tempDir = new File(APP_TEMP_DIRECTORY);
        if (!tempDir.exists()) {
            System.out.println("create tempDir " + tempDir.mkdir());
        } else {
            System.out.println("temp dir exist");
        }

    }


    public static List saveImageFile(String appMainChildDir, String tmpFilePath) {

        File tmpFile = null;
        if (tmpFilePath != null) {
            tmpFile = new File(tmpFilePath);

            if (tmpFile.length() == 0) {
                return noFileOperation();
            }

        } else {

            return noFileOperation();
        }

        File destDirectory = new File(APP_MAIN_DIRECTORY + "/" + appMainChildDir);

        File destFile = new File(destDirectory + "/" + tmpFile.getName());

        if (tmpFile != null && !destFile.exists()) {
            try {

                FileUtils.copyFileToDirectory(tmpFile, destDirectory, false);
                List result = new ArrayList();
                result.add("File saved" + destFile);
                result.add(true);
                return result;


            } catch (Exception e) {
                e.printStackTrace();
                List result = new ArrayList();
                result.add(e.getMessage());
                result.add(false);
                return result;

            }
        } else {

            List result = new ArrayList();
            result.add("the file is exist in destination folder");
            result.add(true);
            return result;


        }
    }

    private static List noFileOperation() {
        List result = new ArrayList();
        result.add("No file");
        result.add(true);
        return result;
    }

    public static HashMap<File, String> getImageFileMap(String intentAction) throws IOException {
        String suffix = intentAction.equals(VIDEO_ACTION) ? ".mp4" : ".jpg";

        String tempFilename = new SimpleDateFormat("yy-MM-dd_HHmmss").format(new Date()) + "__";
        ;
        File storageDir = new File(APP_TEMP_DIRECTORY);

        File resultFile = File.createTempFile(tempFilename, suffix, storageDir);
        String resultFileAbsolutePath = resultFile.getAbsolutePath();
        HashMap<File, String> resultMap = new HashMap<>();
        resultMap.put(resultFile, resultFileAbsolutePath);

        return resultMap;

    }
}
