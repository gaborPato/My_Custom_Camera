package hu.hobbijava.my_custom_camera_app.my_cam_view

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import hu.hobbijava.my_custom_camera_app.R
import kotlinx.android.synthetic.main.activity_play_video.*

class PlayVideoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_play_video)

        if (intent.extras != null) {
            val vidUri = Uri.parse(intent.extras!!.getString("videoUri"))
            video_play_video_act.setVideoURI(vidUri)
            video_play_video_act.start()
        }

    }
}
