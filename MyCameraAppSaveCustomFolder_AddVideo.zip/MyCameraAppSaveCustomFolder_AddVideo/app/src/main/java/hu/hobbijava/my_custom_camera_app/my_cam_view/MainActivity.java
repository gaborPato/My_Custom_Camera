package hu.hobbijava.my_custom_camera_app.my_cam_view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import hu.hobbijava.my_custom_camera_app.R;
import hu.hobbijava.my_custom_camera_app.my_cam_controler.FileTool;
import myMapTool.MapTools;


public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private static final int REQUEST_CAPTURE_CODE = 1000;
    private static final int PERMISSION_REQUEST_CODE = 210;
    private static final String[] NEED_PERMISSIONS = new String[]{
            Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE
    };
    public static final String APP_MAIN_DIRECTORY = Environment.getExternalStorageDirectory() + "/" + "MY_CUSTOM_CAM_APP";
    public static final String[] APP_MAIN_CHILD_DIRS = new String[]{"WORK", "HOBBY", "FAMILY", "HOLYDAY"};
    public static final String APP_TEMP_DIRECTORY = APP_MAIN_DIRECTORY + "/" + ".tmp";
    private static final String FILEMANAGER_PACKAGE_NAME = "com.alphainventor.filemanager";


    private String tmpFilePath = null;
    private Uri tmpFileUri;

    private File tmpFile;
    private boolean savedFile;
    private boolean camResultOK;


    static boolean procedYesAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.image_view);

        checkNeedPermission();

        FileTool.clearTempDirectory();
        savedFile = false;


    }


    private void checkNeedPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            List<String> deniedPermissionList = new ArrayList<>();

            for (String needPermission : NEED_PERMISSIONS) {


                if (checkSelfPermission(needPermission) == PackageManager.PERMISSION_DENIED) {

                    deniedPermissionList.add(needPermission);

                }

            }

            if (!deniedPermissionList.isEmpty()) {
                String[] denArray = (String[]) deniedPermissionList.toArray(new String[deniedPermissionList.size()]);
                requestPermissions(denArray, PERMISSION_REQUEST_CODE);
            } else {
                FileTool.makeApplicationDirectories();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //  super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            int i = 0;
            for (; i < grantResults.length; i++) {

                if (grantResults[i] == PackageManager.PERMISSION_DENIED) {

                    break;
                }

            }
            if (i == grantResults.length) {
                FileTool.makeApplicationDirectories();
            } else {
                Toast.makeText(this, "the application requires permissions to work properly.", Toast.LENGTH_LONG).show();
                checkNeedPermission();
            }

        }
    }

    public void cameraClick(View view) {

        Intent cam_intent = view.getId() == R.id.photo_view_button ? new Intent(MediaStore.ACTION_IMAGE_CAPTURE) : new Intent(MediaStore.ACTION_VIDEO_CAPTURE);


        if (tmpFileUri != null && !savedFile && camResultOK) {

            makeSaveDialog(cam_intent);

        } else {
            savedFile = false;
            openCamera(cam_intent);
        }


    }

    private void makeSaveDialog(Intent cam_intent) {


        AlertDialog.Builder builder = NoSaveAlertDialog.INSTANCE.noSaveAlertDialog(MainActivity.this);

        builder.setOnDismissListener(dialog -> {


            if (procedYesAnswer) {
                openCamera(cam_intent);
            } else {
                return;
            }

        });
        builder.create().show();
    }

    private void openCamera(Intent camera_intent) {
        if (camera_intent.resolveActivity(getPackageManager()) != null) {

            try {
                getFileData(camera_intent);

            } catch (IOException | NullPointerException | IndexOutOfBoundsException e) {
                Toast.makeText(this, "File error", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
                return;
            }


        } else {
            Toast.makeText(this, "no open camera", Toast.LENGTH_SHORT).show();
            return;
        }
        if (tmpFile != null) {
            tmpFileUri = FileProvider.getUriForFile(this, "hu.hobbijava.my_custom_camera_app", tmpFile);
            camera_intent.putExtra(MediaStore.EXTRA_OUTPUT, tmpFileUri);

            startActivityForResult(camera_intent, REQUEST_CAPTURE_CODE);
        } else {
            return;
        }
    }

    private void getFileData(Intent camera_intent)
            throws IOException, NullPointerException, IndexOutOfBoundsException {

        HashMap map = FileTool.getImageFileMap(camera_intent.getAction());
        tmpFile = (File) MapTools.getEntryKey(map, 0);

        tmpFilePath = (String) MapTools.getEntryValue(map, 0);

    }


    public void saveClick(View view) {

        String saveResultTEXT = null;
        final int id = view.getId();
        List saveResultList;

        switch (id) {
            case R.id.save_work_button:
                saveResultList = FileTool.saveImageFile(APP_MAIN_CHILD_DIRS[0], tmpFilePath);
                saveResultTEXT = (String) saveResultList.get(0);
                savedFile = (boolean) saveResultList.get(1);
                Toast.makeText(this, saveResultTEXT, Toast.LENGTH_LONG).show();
                break;

            case R.id.save_hobby_button:
                saveResultList = FileTool.saveImageFile(APP_MAIN_CHILD_DIRS[1], tmpFilePath);
                saveResultTEXT = (String) saveResultList.get(0);
                savedFile = (boolean) saveResultList.get(1);
                Toast.makeText(this, saveResultTEXT, Toast.LENGTH_LONG).show();
                break;
            case R.id.save_family_button:
                saveResultList = FileTool.saveImageFile(APP_MAIN_CHILD_DIRS[2], tmpFilePath);
                saveResultTEXT = (String) saveResultList.get(0);
                savedFile = (boolean) saveResultList.get(1);
                Toast.makeText(this, saveResultTEXT, Toast.LENGTH_LONG).show();
                break;

            case R.id.save_holiday_button:
                saveResultList = FileTool.saveImageFile(APP_MAIN_CHILD_DIRS[3], tmpFilePath);
                saveResultTEXT = (String) saveResultList.get(0);
                savedFile = (boolean) saveResultList.get(1);
                Toast.makeText(this, saveResultTEXT, Toast.LENGTH_LONG).show();
                break;
        }

    }

    public void openFilemanagerAppFolder(View view) {
        try {
            getPackageManager().getPackageInfo(FILEMANAGER_PACKAGE_NAME, 0);
            Intent fileManagerIntent = new Intent(Intent.ACTION_VIEW);
            Uri uri = Uri.parse(APP_MAIN_DIRECTORY);
            fileManagerIntent.setDataAndType(uri, "resource/folder");
            if (fileManagerIntent.resolveActivityInfo(getPackageManager(), 0) != null) {
                startActivity(fileManagerIntent);
            }

        } catch (Exception e) {
            if (e instanceof PackageManager.NameNotFoundException) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + FILEMANAGER_PACKAGE_NAME)));
            } else {
                Log.i("openfolderexception", e.getMessage());
            }


        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        System.out.println("ON ACTIVITY RESULT");
        if (requestCode == REQUEST_CAPTURE_CODE && resultCode == RESULT_OK) {


            if (tmpFileUri.toString().endsWith("jpg")) {
                imageView.setImageURI(tmpFileUri);
            } else {
                imageView.setImageResource(R.drawable.ic_launcher_foreground);
            }

            camResultOK = true;

        } else {
            camResultOK = false;
            imageView.setImageResource(R.drawable.ic_launcher_foreground);

            super.onActivityResult(requestCode, resultCode, data);
        }


    }


    public void play_video_click(View view) {


        if (tmpFileUri != null && tmpFileUri.toString().endsWith("mp4") && camResultOK) {

            Intent videoIntent = new Intent(this, PlayVideoActivity.class);
            videoIntent.putExtra("videoUri", tmpFileUri.toString());
            startActivity(videoIntent);


        } else {
            Toast.makeText(this, "No video", Toast.LENGTH_SHORT).show();
        }
    }
}
